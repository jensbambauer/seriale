---
title: Yasmin C. Rams
image: /img/jury/yasmin-rams.jpg
shortdescription: Producer, Director | Germany
---
<img src="/img/jury/yasmin-rams.jpg">
## Yasmin C. Rams

Producer, Director | Germany


Yasmin C. Rams is  a producer and documentary film director. She studied documentary film in Los Angeles. After working as an assistant at the Yangon Film School in Myanmar, she co-directed the documentary picture „Miriam“ in 2011. After that, she founded her first production company „Lokanat Productions“ and produced several short films with in cooperation with varying producers. In 2012, Yasmin created the short film "A Life in Blue“. She also began the production oft he documentary picture "Im Exil“ by Tin Win Naing. The movie premiered at the Toronto International Film Festival and was also screened at the Busan International Film Festival as well as at the DOK Leipzig. It won a multitude of awards, including "Best Human Rights Documentary“ in Boston. Together with her production partner Rodney Charles, Yasmin founded her second production company Perennial Lens in Darmstadt, Hessen with an office in Los Angeles. At the moment, she finalizes her documentary film "Go Heal Yourself“ in cooperation with 3Sat. Yasmin is an alumni of IDFA Academy. Since 2014, she also is program curator of both the Myanmar Film Festival of Los Angeles and of Diversity in Cannes. In 2017, she was part of the jury oft he Women in Film Finishing Funds. Yasmin is part of the regional comitee oft he AG DoK Hessen and engages in the Junge Generation Hessischen Film.
 



