---
title: Muriel Aboulrouss
image: /img/jury/muriel-aboulrouss.jpg
shortdescription: Artist, Teacher | Home of Cine-Jam, humanitarian arts association co-founder | Lebanon

---
<img src="/img/jury/muriel-aboulrouss.jpg">
## Muriel Aboulrouss

Artist, Teacher | Home of Cine-Jam, humanitarian arts association co-founder | Lebanon

Muriel Aboulrouss is a multiple award-winning cinematographer from Lebanon. Her numerous cinematography credits include multiple feature documentaries, films and web series. “Zyara”, the award-winning doc web series, is her first creation as a director & cinematographer, in partnership with Denise Jabbour, produced by their humanitarian Arts association: Home of Cine-Jam. Muriel is now committed to her mission as a “Zyara” maker and a teacher/ mentor, empowering and guiding filmmakers to finding their cinematic language through Cine-Jam.

 



