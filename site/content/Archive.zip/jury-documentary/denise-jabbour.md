---
title: Denise Jabbour
image: /img/jury/denise-jabbour.jpg
shortdescription: Creative Producer | Home of Cine-Jam, President | Lebanon

---
<img src="/img/jury/denise-jabbour.jpg">
## Denise Jabbour

Creative Producer | Home of Cine-Jam, President | Lebanon

Denise Jabbour is a Creative Producer from Beirut, Lebanon. She started her career as an agency producer at TBWA/RAAD Dubai.
Denise did 2 web-drama series: 'Shankaboot'. It won Reflet d'Or for best web series at the Geneva International Film Festival in 2010 and the International Emmy Award in Cannes 2011 and the series 'Fasateen', which won the Grand Prix Du Jury at Marseille Film Festival. In 2014, she created and produced 'Zyara - the documentary series, as the first creation of her humanitarian arts association "Home of Cine-Jam", which she set up with Muriel Aboulrouss. "Zyara" won 45 international awards so far, and a new season of 12 episodes will be produced every year. Currently, she is running the MENA Media fund for "Visionaire Media" as the head of production and development in the Middle East. 2020 projects include: "Confessions of a Runner", "Daughters of Darkness", "Confessions from the War", and "Arabian Nights."

 



