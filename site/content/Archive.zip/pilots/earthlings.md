---
title: Earthlings 
image: /img/series/earthlings.jpg
---
<iframe width="560" height="315" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Earthlings 
Country: Germany | Genre: Animation, Comedy | Writer, Director, Producer: Jan Riesenbeck | Voice Actor: Michael Iwannek

Each episode of “Earthlings” humorously portrays a typical character of our time, like the hater, the bean counter or the procrastinator.