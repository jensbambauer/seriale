---
title: Lady Priest (German Festival Premiere)
image: /img/series/lady-priest.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/watch?v=WVij8n084jQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Lady Priest (German Festival Premiere)
Country: Australia | Genre: Comedy | Creators, Writers, Producers: Natalia Bornay, Emily Davis | Director: Eva Justine Torkkola | Main Cast: Adele Elasmar, Francesca Waters, Taj Aldeeb, Maria Papas, Adam May, Mitchell Holland, Amanda Falson, Sean Paisley Collins

Three generations of Lebanese-Australian women face their worst nightmares at Sunday lunch. A comedy about being caught between two worlds. About that cathartic moment when you are faced with a life-changing decision. About the complexities (and awesomeness!) of being a second generation Australian.