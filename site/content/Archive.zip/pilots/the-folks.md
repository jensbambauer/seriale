---
title: The Folks 
image: /img/series/the-folks.jpg
---

## The Folks
Country: Germany | Genre: Drama, Comedy, Music | Creator, Writer & Director: Julian Isfort | Producers: Timon Kraaz, Jannik Schnell | Main Cast: Nils Höddinghaus, Anne Ebel, Julian Dietz, Martin Semmelrogge

Alex, an unsuccessful indie folk musician, tries to get his former band together for the prospect of a contract with a band manager. But an old wound within the band structure is not so easy to mend.
