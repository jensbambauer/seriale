---
title: CCF's Solstice Stories 
image: /img/series/ccfs-solstice-stories.jpg
---

## CCF's Solstice Stories
Country: Canada  | Genre: Supernatural, Mystery, Tween, Teen  | Writer & Producer: Kai Damali Little-White | Directors: Kai Damali Little-White, Marel Alemany| Main Cast: Simone Miller, Millie Davis

During a summer solstice 3-day weekend in the woods, four teens discover a mysterious chest with five gifts, five stories, and one warning — don’t sleep. Together, they must unravel this mystery and stay awake if they hope to make it to the final sunrise.
