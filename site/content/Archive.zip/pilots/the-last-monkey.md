---
title: The Last Monkey 
image: /img/series/the-last-monkey.jpg
---
<iframe width="560" height="315" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Last Monkey (International Premiere)
Country: Spain | Genre: Comedy | Creators, Writers & Directors: Lander Múgica, Unai Madariaga | Producers: Lander Múgica, Unai Madariaga, Epic Films (Production company) | Main Cast: Mikel Ibarguren, Andrea Núñez Herrador, Kepa Garcia Icedo, Zorion Egileor, Leire Ormazabal, Itziar Aizpuru, Gaston Haag 

The life of a misfit named Aitor, who dreams of becoming an artist, turns around when he falls in love with an odd girl, sending him on a self-discovery journey. His notion of reality is, however, very different from what others perceive, which will cause him a lot of misunderstanding and problems.