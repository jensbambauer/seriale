---
title: Pulp Air (German Premiere)
image: /img/series/pulp-air.jpg
---
<iframe width="560" height="315" src="https://vimeo.com/919175863" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Pulp Air (German Premiere)
Country: Spain | Genre: Comedy | Creator, Writer, Director:  Anita Pico | Producers: Ro López, José Pico, Anita Pico | Main Cast: Pablo Meixe, Andrea Vilariño, Isabel Garrido, Duarte Galbán, Alberto Abal, Lucía Veiga, Javi Tink, Mayka Braña 

At gate number 24 of the tiny airport in Carballo, you can find the most eccentric and colorful airline of all. Welcome to Pulp Airlines! This mockumentary series shows the daily life of this peculiar company after a new recruit joins the airline. Safe flight!