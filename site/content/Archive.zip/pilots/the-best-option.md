---
title: The Best Option (Out of Competition) (World Premiere)
image: /img/series/the-best-option.jpg
---
<iframe width="560" height="315" src="https://youtu.be/RXAUI5lKMOs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Best Option (Out of Competition) (World Premiere)
Country: Belgium | Genre: Science Fiction | Creator, Writer & Director: Serge Goriely | Producer: Arkadinia | Main Cast: Florence Noirhomme, Romain Mathelart, Takis Chrysanthopoulos 

Under the influence of a mysterious artificial intelligence specialist, Mina has had a virtual assistant, Clara, implanted in her. It allows her to accomplish her dream of becoming a photographer, but distracts her from Ben, her companion, who no longer recognizes her. 
