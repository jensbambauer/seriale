---
title: Tricks and Recipes (Out of Competition) (German Premiere) 
image: /img/series/tricks-and-recipes.jpg
---

## Tricks and Recipes (Out of Competition) (German Premiere)
Country: Spain | Genre: Action-Comedy | Creators & Writers: Rose of Dolls, Oliver Mend | Director: Oliver Mend | Producer: Rose od Dolls | Main Cast: Eneko Irastorza, Arnatz Puertas, Rose of Dolls, Andrea Mora, Sofia Zallio, Miguel Ngu, Ane Lindane, Oliver Mend, Txetxu Llano, Irantzu Núñez, Ana Pan, Irati Herreros, John Gaubeka, Ander Pitt, Andoni Zabala, Iker Zarate

The lives of 15 crazy eclectic characters will intertwine in a crazy comedy that revolves around food, greed, and the need to get the right package sent to the right place. But life isn't perfect, and everyone gets a package they weren't expecting…
