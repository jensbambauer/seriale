---
title: Stadt des Friedens (Out of Competition) (World Premiere)
image: /img/series/stadt-des-friedens.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/IWTI9fOM6UM?si=3wPoekgyNIdXyF7B" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Stadt des Friedens (Out of Competition) (World Premiere)
Country: Germany | Genre: Documentary | Creator, Director & Producer: Dennis Albrecht | Writers: Dennis Albrecht and the Kids | Main Cast: Sophie, Adrian, Lennart, Hannah, Fabienne, Niklas, Matilda, Laura, Ole, Livia

21 young people from the ages of 8 and 16 have produced a fantasy film over the last 2 years. We were with them, consulted and observed them. After 8 days of filming, the big movie was not finished, but the journey through this time was very interesting. 
