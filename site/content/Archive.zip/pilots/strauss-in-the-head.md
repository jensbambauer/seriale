---
title: Strauss in the head 
image: /img/series/strauss-in-the-head.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/watch?v=jZrCQxj6uYg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Strauss in the head
Country: Germany | Genre: Science Fiction | Creator, Writer, Director: Erkan Lüleci | Producers: Erkan Lüleci, Sebastian Kursawe | Main Cast: Nick-Robin Dietrich, Ulrich Günther, Jazzy Gabert

After a car accident in 1990, a homeless man claims to be from 2018. He ends up in a mental institution and doubts reality until he meets a special young man who also seems to know the future.