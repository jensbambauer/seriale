---
title: Thomas Zeug
image: /img/jury/thomas-zeug.jpg
shortdescription: Visual Producer & Filmmaker | ProSiebenSat.1 | Germany 
---
<img src="/img/jury/thomas-zeug.jpg">
## Thomas Zeug

Visual Producer & Filmmaker | ProSiebenSat.1 | Germany

Thomas Zeug is a multiple award-winning filmmaker from Munich. In addition to his work as a Visual Producer at ProSiebenSat.1, he also works on his own film projects. His animated series “2 ALIENS” has already won two awards at the Seriale.
