---
title: Thomas Schneider-Trumpp
image: /img/jury/thomas-schneider-trumpp.jpg
shortdescription: Cartoon-Producer, Director | Playlist 4You  | Germany
---
<img src="/img/jury/thomas-schneider-trumpp.jpg">
## Thomas Schneider-Trumpp

Cartoon-Producer, Director | Playlist 4You | Germany

Thomas Schneider-Trumpp is an Animation Producer and Distribution Entrepreneur with over 25 years of experience in international film production. He was born in 1969 in Chemnitz, formerly known as Karl-Marx-Stadt in East Germany.
Thomas is co-founder of Playlist 4You GmbH and Watch Movies GmbH and director and founder of Clayart Trickfilmproduktion GmbH, and more. His background ranges from experience as an entrepreneur in the field of web-only productions to business development with pragmatic approaches to feasibility and business concepts with a focus on creation. Since 2005 he is a producer of original content for the web with more than 300 films produced and more than 40 million views in total.


