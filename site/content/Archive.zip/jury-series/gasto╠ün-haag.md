---
title: Gastón Haag
image: /img/speaker/gastón-haag.jpg
shortdescription: Director, Actor, Writer | Arcanoide Films |Spain
---
<img src="/img/speaker/gastón-haag.jpg">
## Gastón Haag

Director, Actor, Writer | Arcanoide Films |Spain

Gastón Haag is a director, actor and screenwriter known for his particular and absurd humor that is reflected in both, in its characters and in each one of his audiovisual projects. He directed and scripted series like “The Marvelous Hoolister Park”, “Hotel Romanov”, “Fehler 78” and “Backstage”, which is currently on Amazon Prime Spain. Currently living in Spain, he dedicates his time to new audiovisual projects. At the moment, he is filming a series for Disney and finishing the upcoming short film “Superjodidos”.