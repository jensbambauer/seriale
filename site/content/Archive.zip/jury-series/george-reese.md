---
title: George Reese
image: /img/jury/george-reese.jpg
shortdescription: Executive | Seeka TV | United States 
---
<img src="/img/jury/george-reese.jpg">
## George Reese

Executive | VP of Programming, Seeka TV | United States 

George Reese has worked in television, film, and technology as an entrepreneur and independent filmmaker for over 30 years. He has started several companies and worked on dozens of productions in just about every behind-the-camera role imaginable. His previous company, Enstratius, was acquired by Dell in 2013. George co-founded Seeka TV, where he is the Vice President of Programming and leads a team that seeks out the highest quality shows for the platform. The team scours festivals for the best of the best and brings them to Seeka TV. In addition, he serves as Executive Producer on select co-produced and original Seeka TV content. George is also a filmmaker himself. The pilot of his latest series, âUtopia Planitiaâ, has won multiple awards on the festival circuit, and the full series is currently making the festival rounds.

