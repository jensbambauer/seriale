---
title: Dipu Bhattacharya
image: /img/jury/dipu-bhattacharya.jpg
shortdescription: Producer, Director | United States  
---
<img src="/img/jury/dipu-bhattacharya.jpg">
## Dipu Bhattacharya

Producer, Director, Writer, Editor | Co-Creator of The Pantsless Detective | United States

Deep in the heart of Texas, Dipu Bhattacharya is the co-creator of the award-winning comedy noir digital series “The Pantsless Detective”. He has won awards for writing, editing, and directing the series, including the prestigious Michael Ajakwe Jr. Achievement Award at Melbourne Web Fest and Marseille Web Fest. Wearing many hats in front of and behind the camera, he also has nominations ranging from Best Visual Effects to Best Supporting Actor. A well-travelled fixture at web fests around the world in the Before Times, he has moderated panels and screenings at Bilbao Seriesland, moderated live and virtual panels at Minnesota WebFest, and made multiple guest appearances on digital shows such as “Super Geeked Up” and “The Nicole and Tonya Show”.


