---
title: Kate Madison
image: /img/jury/kate-madison.jpg
shortdescription: Actress, Creator | United Kingdom
---
<img src="/img/jury/kate-madison.jpg">
## Kate Madison

Actress, Creator, Director, Producer | United Kingdom

Kate is known for directing, producing and acting in her Lord of the Rings prequel, Born of Hope, released on the internet back in December 2009 with over 50 million views to
date and more recently her award-winning fantasy series Ren: The Girl with the Mark that is available to view on Amazon Prime and YouTube as well as other independent platforms. Her love of bringing ambitious high quality historical or fantasy projects to life, often with such a small budget that most people would be terrified by the thought, has given her unique experiences and skills that she is passionate about sharing with others. As well as developing new projects Kate livestreams regularly over on Twitch and is a cast member in a number of RPG shows. You can learn more at Katemadison.net. Kate is honoured to have been asked to join the Jury for this year's die Seriale.
