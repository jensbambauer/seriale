---
title: Young Man Kang
image: /img/speaker/young-man-kang.jpg
shortdescription: Director | YMK Films | Founder & Festival Director of Seoul Webfest & Asia Web Awards | Festival Director of LAWEBFEST | South Korea
---
<img src="/img/speaker/young-man-kang.jpg">
## Young Man Kang

Director | YMK Films | Founder & Festival Director of Seoul Webfest & Asia Web Awards | Festival Director of LAWEBFEST | South Korea

Young Man Kang directed several feature films and over 10 web series. All feature films have been released on VOD in Netflix and Amazon in the US, and have sold in 15 countries. He has a total of 18 awards from a number of film festivals and webfests. Young Man Kang collaborated with fellow film "Avatar" alumni, Just Cause 3D, on his "4D Experience" Project. His latest series "Lotte Haus" won 8 awards and got selected by over 30 film festivals. He is Founder and Executive Director of Seoul Webfest & Asia Web Awards. He has been a Jury Member at several web fests such as Die Seriale, Digital Media Webfest and more. Also he became Festival Director of LAWEBFEST 2022.