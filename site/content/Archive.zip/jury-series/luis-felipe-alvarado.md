---
title: Luis Felipe Alvarado
image: /img/jury/luis-felipe-alvarado.jpg
shortdescription: Audiovisual Script Writer | Lima Web Fest | Peru
---
<img src="/img/jury/luis-felipe-alvarado.jpg">
## Luis Felipe Alvarado

Audiovisual Script Writer | CEO & Founder of Lima Web Fest | Peru

Luis has an MBA in Business Administration and a Communication degree with over 25 years of teaching and writing scripts for television. He is a Screenwriter of several TV formats, especially soap operas, which include "Luz Maria", "Isabella", "Soledad", released in Peru and parts of Europe and Asia. Luis is a Script doctor for various television networks in North and South America. Moreover, he is the academic director of the Communications Department with studies such as Photo, Audiovisual and Multimedia, Advertising and Cinematography in Toulouse Lautrec, School of Design and Communications, that is over 35 years in the market. Jury in Emmy Awards 2015, Roma Web Fest and Seoul Web Fest in 2018 and 2019. Alvarado is a University teacher of advanced scripts courses and the Founder and the CEO of Lima Web Fest.