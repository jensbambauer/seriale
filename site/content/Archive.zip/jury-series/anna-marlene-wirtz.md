---
title: Anna-Marlene Wirtz
image: /img/speaker/anna-marlene-wirtz.jpg
shortdescription: Writer, Producer, Actress | Germany
---
<img src="/img/speaker/anna-marlene-wirtz.jpg">
## Anna-Marlene Wirtz

Writer, Producer, Actress | Germany

Anna-Marlene Wirtz, of Welsh & German origin, is an actress working predominantly in Film, Theatre and Voice over's. After having trained and lived in London, she is now based in Berlin. Anna worked on the Hesse produced digital series ANOMALIE (Tag & Nacht Media) playing the role of Luisa Ahrens, for which she was awarded BEST ACTRESS in a Sci-Fi at Asia Web Awards. In 2013 she co-produced her first Sci-Fi Pilot, illuminating a passion for working behind the camera. In 2020, together with her good friend and colleague Elena Halangk, she then wrote, produced and acted in their web series EMMY & CHRISTIN. It was clear to them both, they wanted to create something they would like to watch themselves, which meant, it had to be a story about friendship between women, conflicts, absurdity, adventure and blood. Their web series enjoyed several recognitions, including Best Web Series (British Web Awards), Best Cast (BiSeriesland) and Best German Series (Webfest Berlin).