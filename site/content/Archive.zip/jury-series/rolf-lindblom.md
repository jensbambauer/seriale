---
title: Rolf Lindblom
image: /img/jury/rolf-lindblom.jpg
shortdescription: Filmmaker | Viking Film Productions | Finland
---
<img src="/img/jury/rolf-lindblom.jpg">
## Rolf Lindblom

Filmmaker | Viking Film Productions | Finland

Rolf Lindblom is a multi award-winning filmmaker and founder of Viking Film Productions - thoughts not only on filmmaking, but on life as a creative person, being a lifelong learner, and living day-to-day as a person who is a big fan of cinema.

