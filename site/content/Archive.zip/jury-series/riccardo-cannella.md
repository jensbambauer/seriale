---
title: Riccardo Cannella
image: /img/jury/riccardo-cannella.jpg
shortdescription: Cinnamon Digital Cinema Production | Sicily Web Fest | Italy
---
<img src="/img/jury/riccardo-cannella.jpg">
## Riccardo Cannella

Producer, Director, Screenwriter | President of Cinnamon Digital Cinema Production | Founder of Sicily Web Fest | Italy

Director, producer and screenwriter, winner of 8 international awards for best director, from Los Angeles to Bilbao. Digital serial expert for cinema and web. Founder of the Sicily Web Fest, a festival that brings numerous professionals from all over the world to Sicily and founder of Cinnamon Digital Cinema Production, which has obtained over 40 awards worldwide. Awarded by the mayor of Palermo, Leoluca Orlando, with the "Prestigiosa Tessera del Mosaico" as excellence for the city of Palermo.

