---
title: Sebastian Simon
image: /img/jury/sebastian-simon.jpg
shortdescription: Producer | PixelPEC | Germany
---
<img src="/img/jury/sebastian-simon.jpg">
## Sebastian Simon

Producer | PixelPEC | Germany

Sebastian is founder and managing producer of the Offenbach-based animation and film production company PixelPEC. The company focuses on developing its own film and series formats for TV and VOD. PixelPEC is a member of the Association of Hessian Film Industry and is committed to the interests of the Junge Generation Hessischer Film (Young Generation Hessian Film), an interest club of Hessian newcomer filmmakers to politics and business.

