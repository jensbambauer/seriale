---
title: Thomas Meudt
image: /img/jury/thomas-meudt.jpg
shortdescription: Producer | Tag & Nacht Media | Germany 
---
<img src="/img/jury/thomas-meudt.jpg">
## Thomas Meudt 

Music & Film Producer | Tag & Nacht Media | Germany 

Raised up between Darmstadt and Frankfurt, Thomas very early to have fun making music. Over the next years he wrote his first songs and lyrics, played in several bands and created songs for a solo project. There was only one way to go on, so the next step was to study producing music, sounddesign and concepting mutlimedia projects. Getting to know his nowaday collegues Stephan and Christian, the three founded „Tag & Nacht Media“ - a production company for mainly audiovisual contents. With their first series „MEM“ the first step into the field of storytelling in series format was done. A few years later, the mystery series “Anomalie“ was the first full-length series production with 10 episodes of 20 min each. After a lot of succesful national and international festivals, Thomas is part of Seriale Jury for the second time. 

