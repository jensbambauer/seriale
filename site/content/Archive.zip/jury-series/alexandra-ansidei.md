---
title: Alexandra Ansidei
image: /img/jury/alexandra-ansidei.jpg
shortdescription: Actress | France
---
<img src="/img/jury/alexandra-ansidei.jpg">
## Alexandra Ansidei

Actress | France

After a career as a classical dancer, Alexandra Ansidei decided to become an actress. In Paris, she took some acting classes and began to work in tv shows, feature films and performed in several plays in France and appeared in tv movies in Spain and Turkey.  During her childhood, she was raised in different countries and developed the abilities to speak several languages. In 2015 she performed in the web series Osmosis which won 13 prizes, including best visual effects at Die Seriale!


