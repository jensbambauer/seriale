---
title: Suzette Laqua
image: /img/jury/suzette-laqua.jpg
shortdescription: Executive | Vancouver Web Fest | Canada
---
<img src="/img/jury/suzette-laqua.jpg">
## Suzette Laqua

Executive Director & Founder of Vancouver Web Fest | Canada

Suzette Laqua is Canadian and the Executive Director & Founder of Vancouver Web Fest, Canada’s Premier International Digital Storytelling Festival & Conference. She is an entrepreneur, Executive Producer, Producer and Writer of TV, Web Series and Films.


