---
title: Gisela Benenzon
image: /img/jury/gisela-benenzon.jpg
shortdescription: Screenwriter | Argentina
---
<img src="/img/jury/gisela-benenzon.jpg">
## Gisela Benenzon

Screenwriter, Director | Argentina

Gisela Benenzon is a director, screenwriter and playwright. She worked as an author for TelefÃ©, Pol-Ka (Argentina), Televisa (Mexico), E! Entertainment Television and Mac Guffin (Spanien). She also worked as director and screenwriter of the Short Film "Treatment" and digital series "Soy Ander" and "In-Network", all of the winners in the Competition of INCAA, and nominated for several international festivals. She is the screenwriter of the feature films "Dead Birds", "When I see you again" and "The dance". Gisela is the winner of the Ministry of Culture of Madrid scholarship for the script "Lies about Ava". She wrote the plays "I love you like the air I breath" and "To whom it corresponds", both for the Ministry of Culture of the Nation, and also several plays released in "Microteatro". Benenzon is the winner of the Artei theater prize for the work "The triangle of Bermuda" and the writer of the popular series "Apache: the life of Carlos Tevez". She participated as a member of the jury in several scripts and digital series contest.

