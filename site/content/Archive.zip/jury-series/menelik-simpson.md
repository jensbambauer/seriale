---
title: Menelik Simpson
image: /img/jury/menelik-simpson.jpg
shortdescription: Writer, Director | United Kingdom
---
<img src="/img/jury/menelik-simpson.jpg">
## Menelik Simpson

Writer, Director | United Kingdom

Born in London, Menelik attended The BRIT School, where he studied Broadcast and Digital Communication and then went on to pursue a career in video editing and camera work. As a writer and director, Menelik has produced short films and television pilots. His first web series, "Darren Has A Breakdown" premiered at Raindance Web Fest 2014 and has screened in a multitude of festivals around the world. The series earned Menelik the Best Amets Director award at Bilbao Webfest 2015 and the Filmmaker Amets award at Bilbao Webfest 2016.


