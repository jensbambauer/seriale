---
title: John Tague
image: /img/jury/john-tague.jpg
shortdescription: Actor, Director | United States
---
<img src="/img/jury/john-tague.jpg">
## John Tague

Actor, Producer, Director | United States

John Tague recently starred in FX's "American Horror Story 1984", Hulu's "Light As A Feather, Fox's "Lucifer", "Why Not Choose Love: A Mary Pickford Manifesto" with Cary Elwes, NBC's "The Blacklist", "CSI: Cyber" On CBS, "Maron" on IFC, "General Hospital", and is the lead actor and creator of the multi-award web-series "The Rolling Soldier" which he also wrote and directed. He has appeared in the lead role of action/thriller feature "The Ticking Man" by Next Generation Films, "Living and Dining" with Maureen Stapleton, the hit FOX TV show "24", NBC's "Crossing Jordan" and ABC's "All My Children". John comes from Chatham, New Jersey and now resides in Los Angeles with his wife Claire Hartley and their daughter Nova.


