---
title: Lucie Tournant
image: /img/jury/lucie-tournant.jpg
shortdescription: Actress, Director | France
---
<img src="/img/jury/lucie-tournant.jpg">
## Lucie Tournant

Actress, Writer, Director | France

Lucie Tournant is a French director, writer and actress. Born with a passion for creative arts, she first started in a local improv and drama class. Then, she enrolled in the Ecole Périmony drama school in Paris. After taking classes at The Promenade Playhouse Santa Monica, Los Angeles, she took cinema classes with Jérôme Genevray in Paris and starred in different plays and film projects. Following all of this, she chose to embrace her independent streak and create, direct and star in her own web series “Weakness”, which was nominated at the LAWEBFEST 2017. She received the award of "Best Director” at the die Seriale 2017 in Giessen, Germany.



