---
title: Lotte Ruf
image: /img/jury/lotte-ruf.jpg
shortdescription: Producer | Haus Kummerveldt Filmproduction | Germany

---
<img src="/img/jury/lotte-ruf.jpg">
## Lotte Ruf

Producer | Haus Kummerveldt Filmproduction | Germany

Born in 1996 in Düsseldorf, Lotte studied Film & Sound at the university of arts Dortmund. In 2013 she founded the video competition „24h To Take“ for the Filmwerkstatt Düsseldorf e.V., which she manages until today. In 2015 Lotte began her academic studies at film school. As the projects became larger, she started focussing on production - and loved it. 2017 she started her first feature film and produced several short films. Along with her studies, she was part of several international Filmfestival juries. In February 2020, she graduated from film school Dortmund with the pilot season of „Haus Kummerveldt“, which was, awarded the FIRST STEPS AWARD. After her first cinema feature, she started her master of film production at the film university Babelsberg.

 



