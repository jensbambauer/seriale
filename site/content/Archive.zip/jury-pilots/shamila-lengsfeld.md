---
title: Shamila Lengsfeld
image: /img/jury/shamila-lengsfeld.jpg
shortdescription: Director, Screenwriter  | Germany

---
<img src="/img/jury/shamila-lengsfeld.jpg">
## Shamila Lengsfeld

Director, Screenwriter  | Germany

Shamila Lengsfeld is a German Film Director and Screenwriter. She grew up at the Lake of Constance in South Germany and did an apprenticeship in Cinema Management and Film Projectionist before studying at Film School. After graduating from the Middlesex University with a Bachelor of Film Making in 2016, she became known to a wider public through her Sci-Fi movie Blake, awarded with the German Newcomer Film Award. Shamila combines Sci-Fi and all kinds of Genres with Social topics.

 



