---
title: Martin Otto 
image: /img/jury/martin-otto.jpg
shortdescription: Cinema Manager | Kinocenter Giessen | Germany 

---
<img src="/img/jury/martin-otto.jpg">
## Martin Otto 

Cinema Manager | Kinocenter Giessen | Germany 

Martin Otto was born in Weilburg in 1985. His love for cinema awakened when he went to see "Good Will Hunting" at school and has grown steadily ever since. As early as 2008, Martin began working in various positions as part of the team at Kinocenter Giessen alongside his studies. Since 2015, he has been the operations manager and responsible for the orientation towards an arthouse cinema. As one of the first major projects, he was able to welcome die Seriale to the cinema in its founding year and has since offered it at home for screenings, discussions and forums for any kind of exchange.''
 



