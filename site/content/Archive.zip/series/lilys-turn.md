---
title: Lily's turn (German Premiere)
image: /img/series/lilys-turn.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/a-le7S1qyLE?si=Y8L0cu5-i2P4ICDS" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Lily's turn (German Premiere)
Country: Iran | Genre: Magic Realism | Creator, Director & Producer: Rouhollah Hejazi | Writers: Mehdi Shirzad, Soroush Chitsaz | Main Cast: Pardis Ahmadieh, Merila Zare'i, Hamid Farrokhnezhad

Through a mysterious book, Lily discovers that she and her family have lived in many times and places, and now it is Lily's turn to decipher the book and find a valuable painting of her ancestors to make a choice that gives meaning to all these lives. 
