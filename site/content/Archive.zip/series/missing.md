---
title: Missing
image: /img/series/missing.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/PqYlDupTolY?si=93LjDG5T7iyWrbpr" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Missing
Country: Argentina | Genre: Drama, Historical | Creator & Director: Mariano Pozzi | Writers: Mariano Pozzi, Agustín Muñiz | Producers: Marina Marin, Natacha Bucatari, Mariano Pozzi | Main Cast: Mara Bestelli, Tom CL, Lola Chiara Carelli García, Romina Escobar, Rita Terranova, Santiago Kuster, Dana Crosa, Elena Petraglia

During the 1976 dictatorship in Argentina, more than 500 babies and very young children were kidnapped and relocated to new families by the Armed Forces. Each episode portrays a story inspired by a real case, linked to the search for and restitution of the identity of these children.
