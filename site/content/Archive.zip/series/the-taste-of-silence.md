---
title: THE TASTE OF SILENCE (World Premiere)
image: /img/series/the-taste-of-silence.jpg
---
<iframe width="560" height="315" src="https://drive.google.com/file/d/1rpMssH3-s7cmLN842xT77Ad5Xqo6bfW_/view?usp=drive_link" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## THE TASTE OF SILENCE (World Premiere)
Country: Argentina | Genre: Drama, Thriller | Creators: Mariano Hueter, Martin Kweller | Writers: Mariano Hueter, Rodo Serviño | Director: Pedro Levati | Producers: Mariano Hueter, Maru Mosca, Guido Kaczka, Martin Kweller | Main Cast: Gonzalo Heredia, Violeta Urtizberea, Luciano Castro, Agustin Sullivan, Cande Molfese

Vicente Olivar is a renowned chef. One night, a dinner with politicians ends in the worst way after a presidential candidate tries to abuse Vicente's wife. The event becomes an accidental crime that our protagonist must hide while discovering secrets that should never have been revealed.
