---
title: I WILL BURY YOU (Season 2) (European Festival Premiere)
image: /img/series/i-will-bury-you.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/sKHRERe6bVA?si=MRxj3_ayVoL_P74P" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## I WILL BURY YOU (Season 2) (European Festival Premiere)
Country: Canada | Genre: Comedy | Creators: Ravi Steve Khajuria, Sergio Di Zio, Colin Glazer | Writer & Director: Ravi Steve Khajuria | Producers: Ravi Steve Khajuria, Colin Glazer, Sergio Di Zio | Main Cast: Sergio Di Zio, Colin Glazer, Clare Coulter, Saul Rubinek 

“I Will Bury You” is a Canadian, dark comedy series that follows two brothers as they attempt to carry out their mother's final wishes by scattering her ashes in the places she loved… if they can only figure out where that might be.
