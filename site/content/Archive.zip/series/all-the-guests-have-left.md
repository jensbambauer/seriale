---
title: all the guests have left 
image: /img/series/all-the-guests-have-left.jpg
---

## all the guests have left 
Country: Germany | Genre: Horror, Drama, DeComposition | Creator, Writer, Director, Producer: Dion Schumann | Main Cast: Kalin Heidinger, Charles Rettinghaus, Karime Vakilzadeh, Lars Nagel, Klaus Barkowsky, Dietrich Kuhlbrodt

Drug-addict Scumfuck Speedy finds himself in a downward spiral when he is forced into prostitution by his pimp and legal guardian uncle Helmut. A bizarre glimmer of hope lights up on the horizon, when an elderly couple hires him to play their never-born newborn. Slowly he loses himself in his new role.
