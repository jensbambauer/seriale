---
title: Haus Kummerveldt
image: /img/series/haus-kummerveldt.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/RqdHGCs6XA8?si=v9yNRXnyL48XLHzP" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Haus Kummerveldt
Country: Germany | Genre: Period Piece Dreamed | Creator & Director: Mark Lorei | Writers: Cecil Joyce Röski, Charlotte Krafft | Producer: Lotte Ruf | Main Cast: Milena Straube, Marcel Becker-Neu, Leonie Rainer, Wolf Danny Homann, Rosa Lembeck, Fabian Nolte

“Haus Kummerveldt” is a fictional web series set in the late 19th century in Münsterland and focuses on female emancipation. Melancholy, morbidity and dark humor are the essentials of the story.
