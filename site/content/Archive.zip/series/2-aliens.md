---
title: 2 Aliens (Out of Competition)
image: /img/series/2-aliens.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/ySU-jLk0PJU?si=Q9c12Ildb7J9acIP" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## 2 Aliens (Out of Competition)
Country: Germany | Genre: Animation, Science Fiction | Creator, Writer, Director & Producer: Thomas Zeug | Main Cast: Thomas Zeug, Stephanie Zeug

The two chaotic aliens Quiqueck & Hämat stumble upon a mysterious space nebula. When all systems fail, Captain Quiqueck decides to freeze himself and Hämat has to take over. But it's not just the responsibilities of a captain that hold a certain attraction!
