---
title: Buschka discovers Germany - Show me Democracy! (Out of Competition) (World Premiere)
image: /img/series/buschka-discovers-germany.jpg
---

## Buschka discovers Germany - Show me Democracy! (Out of Competition) (World Premiere)
Country: Gemany | Genre: Documentary | Creator, Writer & Director: Jörg Buschka | Producer: Jörg Buschka (on behalf of Landeszentrale für politische Bildung Rheinland Pfalz) | Camera: Stefan Pohl | Main Cast: Ausbilder Schmidt, Guildo Horn, Sarah Traub, Tino Leo, Uwe John | Host/On-Reporter: Jörg Buschka

Buschka discovers Germany – Show me Democracy! The early democratic movement in Rhineland-Palatinate. Jörg Buschka meets comedian Ausbilder Schmidt, singer Guildo Horn, historians and actors, learning how democracy flared up in 1792, solidified at Hambach Festival 1832 and got pushed back in 1849. 
