---
title: Memories of a forgotten Childhood (World Festival Premiere)
image: /img/series/memories-of-a-forgotten-childhood.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/875485158?h=865e9dc332" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Memories of a forgotten Childhood (World Festival Premiere)
Country: Germany | Genre: Drama | Creators: Lars Smekal, Nico Drago | Writer & Director: Lars Smekal | Producer: Nico Drago | Main Cast: Julian Ehrenfried, Sarah Grunert, Christian Stock

While father Rudi desperately tries to regain the lost family happiness at the slot machine, son Niklas (11) is often alone with his alcoholic mother Anna. Niklas is torn between his sense of duty to help his parents and his desire to escape his childhood home.
