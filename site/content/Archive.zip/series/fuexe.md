---
title: Füxe 
image: /img/series/fuexe.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/B3q71xiGgwI?si=NTe3kdNWPYWzS5rm" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Füxe
Country: Germany | Genre: Drama | Creator: Joe Hofer | Writers: Joe Hofer, David Clay Diaz | Directors: David Clay Diaz, Susan Gordanshekan | Producers: Katrin Haase, Oliver Arnold | Main Cast: Valon Krasniqi, Roxana Samadi, Vito Sack, Ferdinand Lehmann, Richard van Weyden

A student from a modest, immigrant background hopes that membership of a student fraternity will pave his way to a successful future, but must realize that the world of the elites will only open up to him if he is prepared to make sacrifices and deny himself.
