---
title: Family Therapy (International Premiere)
image: /img/series/family-therapy.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/PiBq4sTfb6o?si=B42xHR5KcLEzX_En" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Family Therapy (International Premiere)
Country: Argentina | Genre: Dramedy | Creators: Gonzalo Arias, Ariana Saiegh | Writer: Ariana Saiegh | Director: Alejandro Ciancio | Producers: Gonzalo Arias, Pablo Giles, Martín Lapissonde | Main Cast: Boy Olmi, Carola Reyna, Inés Efron, Teo D’Elia, Nora Cárpena 

A married couple, both alternative therapists, decide to split up, but continue to work together as co-therapists. Now, they try to help their patients, but their own problems become the protagonists of the sessions, meanwhile they deal with the conflicts of their children: Mara and Abel.
