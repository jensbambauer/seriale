---
title: Beyond Fashion (Season 2) (International Festival Premiere)
image: /img/series/beyond-fashion.jpg
---
<iframe width="560" height="315" src="https://www.ardmediathek.de/video/beyond-fashion/trailer-beyond-fashion-staffel-2/ard-kultur/Y3JpZDovL21kci5kZS9iZWl0cmFnL2Ntcy80NmZmNTJlYy1iOWY0LTQ5YTktODJhOS1lZGYzZjlkOWE2NmY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Beyond Fashion (Season 2) (International Festival Premiere) 
Country: Germany | Genre: Documentary | Creators: Susanne Bauer, Ineke Hagedorn, Manuel Freundt | Writer: Susanne Bauer | Directors: Paola Calvo, Patrick Jasim | Producers: Ineke Hagedor (Senior), Weiya Yeung (Junior) | Host: Avi Jakobs

“Beyond Fashion” delves into the world of people for whom fashion is a way of life and a way of expressing their identity. Host Avi Jakobs discusses topics that concern us all.