---
title: Super Fails
image: /img/series/super-fails.jpg
---

## Super Fails
Country: Germany | Genre: Animation, Political Satire | Creator, Writer: Robert Jahn | Creative Directors: Deveroe, Robert Jahn | Producer: Bastian Asdonk | Voice: Markus Haase

There are ideas, experiments, inventions and moves that have earned their place in the history books. Most of them because they were particularly good ideas, experiments, inventions and moves. ARTE “Super Fails” tells us about the rest.

