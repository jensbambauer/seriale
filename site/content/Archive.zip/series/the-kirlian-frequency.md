---
title: The Kirlian Frequency (Season 2) (German Premiere)
image: /img/series/the-kirlian-frequency.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/924774872?h=111bbecf3b&amp;badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Kirlian Frequency (Season 2) (German Premiere)
Country: Argentina | Genre: Animation, Horror, Drama | Creators: Cristian Ponce, Hernan Bengoa | Writers: Cristian Ponce, Hernan Bengoa | Director: Cristian Ponce | Producers: Pedro Saieg, Sergio Sosa

It's 1987 and “Ingeniero Kirlian”, a small town lost somewhere in Argentina, is haunted by an enigmatic radio show. “The Kirlian Frequency" reports strange stories that torment the locals, and its shady and lonely DJ seems to know a little too much about these events.

