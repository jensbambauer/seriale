---
title: 2 Minutes - 24/7 
image: /img/series/2-minutes-24-7.jpg
---

## 2 Minutes - 24/7
Country: Germany | Genre: Dramedy | Creators, Directors: Lisa Miller, Leonie Krippendorff | Writers: Lisa Miller, Leonie Krippendorff, Alice Gruia | Producers: Daniela Zentner, Yvonne Abele | Main Cast: Lucie Heinze, Lena Klenke, Banafshe Hourmazdi, Omar El-Saeidi, Johanna Franke, Taneshia Abt, Kathi Wolf, Rupert Markthaler, Barbara Colceriu, Laurence Rupp, Luisa Wöllisch, Simon Rupp 

24 hours can seem like an eternity when a crying baby has taken over; when you're fed up with social media, don't feel seen and your stomach looks like a battlefield. Whether it be at baby swimming classes, mediation or your bestie's birthday, nothing goes as planned for six women.
