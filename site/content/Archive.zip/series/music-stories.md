---
title: MusicStories (World Premiere)
image: /img/series/music-stories.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/922108314?h=60db576879&amp;badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## MusicStories (World Premiere)
Country: Germany | Genre: Drama, Adventure, Comedy, Experimental Thriller | Creators & Directors: Elena Walter, Emanuel Fusillo, Matthias Hektor Ventker | Writers & Producers: Elena Walter, Emanuel Fusillo | Director: Guto Aeraphe | Main Cast: Peter Weiss, Neele Pettig, Luisa Maria Bruer, Jean-Loup Fourure, William Anthony Schönfelder, Konrad Lohrmann, Reneé Vanessa Branderhorst, Saltanat Akdeniz, Christian Walter, Mona Kammer

The anthology series tells six stories inspired by classical music by using different genres and visual languages, from silent film to comedy. Newly interpreted classics such as Beethoven's “Für Elise” serve as the score, offering a new approach by combining classical music and narrative cinema.
