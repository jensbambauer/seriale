---
title: No One Around (German Festival Premiere)
image: /img/series/no-one-around.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/919759541?h=4ec8f563b2" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## No One Around (German Festival Premiere)
Country: Uruguay | Genre: Comedy | Creator, Writer, Director: Joaquín Bravo | Producers: Patricia Canén, Joaquín Bravo | Main Cast: Diego Licio, Mirella Pascual, Pilar Roselló, Victoria Coto, David Roizner, Ignacio Revello, Javier Chávez, Mariana Escobar, Emanuel Sobré, Domingo Milesi

“No One Around” is a comedy web series composed of stand-alone episodes which make fun of everyday current situations. The series tone goes from existential humor to the absurd. The episodes average 8 minutes in length. It is a fast and easy to watch product, as its episodes are short, it deals with familiar topics and it is comedy.
