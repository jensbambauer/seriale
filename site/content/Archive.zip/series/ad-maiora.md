---
title: AD Maiora (International Premiere)
image: /img/series/ad-maiora.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/oLVsOphqjL8?si=BJZhAczjaIZ-BkzE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## AD Maiora (International Premiere)
Country: Italy | Genre: Documentary | Creator: Deborah Annolino | Writer: Stefano Foglia | Director: Angelo Giummarra | Producer: AD Communications

An emotional journey into the world of fragility, through the research and the narration of positive stories and good practices. The protagonists are men and women who, thanks to their ability to react to adversity, become an inspiration to others. “AD Maiora” tells stories and social issues.
