---
title: The Method. Foundation of Identity (World Festival Premiere)
image: /img/series/the-method.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/894505651?h=6cc1b08fd9" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Method. Foundation of Identity (World Festival Premiere)
Country: Argentina | Genre: Political Thriller | Creators: Maximiliano Monzon, Gonzalo Arias | Writers: Maximiliano Monzon, Laura Seijo, Federico Alvarado, Nicolás Britos | Director: Mariano Minestrelli | Producers: Martín Froilán Lapissonde, Daniela Martinez Nannini | Main Cast: Paola Barrientos, China Pereiro, Juan Cruz Marquez

In a country where identity is still an issue, a scientist solves cases following the legacy of her grandfather, Juan Vucetich, the renowned Argentinian-Croatian creator of the fingerprints identification method. Her job and name are threatened, so she embarks on a journey to discover who is behind it.


