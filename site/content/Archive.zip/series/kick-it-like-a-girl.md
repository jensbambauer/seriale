---
title: Kick it like a girl
image: /img/series/kick-it-like-a-girl.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/0YHiB0G5yCY?si=cCWpta8ZBa2MSmfg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Kick it like a girl
Country: Germany | Genre: Documentary | Creator, Writer, Director & Producer: Karin de Miguel Wessendorf | Main Cast: Chayenne, Eriona, Pauline, Liv

Everything revolves around football for Chayenne, Eriona, Liv and Pauline. They play in the U15 squad of SGS Essen, one of the few clubs in Germany that gives priority to women's soccer. This season it's all or nothing for the players, as they want to win the Niederrhein Cup.
