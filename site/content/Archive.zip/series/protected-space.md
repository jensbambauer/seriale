---
title: Protected Space (International Premiere)
image: /img/series/protected-space.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/JzM1tUrt23s?si=4F1c1bZRZglVp2UD" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Protected Space (International Premiere)
Country: Israel | Genre: Comedy | Creator, Writer: Anna Fatahov | Director: Eyal Dickman | Producers: Ram Manovich, Anna Fatahov, Nitzan Rothschild, Eyal Dickman | Main Cast: Anna Fatahov, Nitzan Rothschild, Dor Baranes, Nofar Baranes

In the midst of a military operation, a group of Israeli college students is determined to maintain sanity and live their lives to the max.
