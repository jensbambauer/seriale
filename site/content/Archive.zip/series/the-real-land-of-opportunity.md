---
title: The Real Land of Opportunity (German Premiere)
image: /img/series/the-real-land-of-opportunity.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/866962262?h=8c240c5832" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Real Land of Opportunity (German Premiere)
Country: Russian Federation | Genre: Documentary | Creator & Director: Andrey Ananin | Writers: Andrey Ananin, Roman Shtyl-Bitins, Galina Masalova | Producers: Igor Mishin, Angelina Ashman, Daria Fedotova | Main Cast: Justus Walker, Vladimir Yakunin, Andrey Mitsai

An optimist farmer from the USA and his new Siberian friends with a criminal past want to start a new life from scratch, but on the way to their dream, they face harsh Russian reality.


