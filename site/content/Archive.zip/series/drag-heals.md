---
title: Drag Heals (Season 4) 
image: /img/series/drag-heals.jpg
---

## Drag Heals (Season 4) 
Country: Canada | Genre: Documentary, Drag | Creators: Tracey Erin Smith | Director, Writer & Producer: Charlie David | Host: Tracey Erin Smith

“Drag Heals” follows drag artists building their own stage show from deeply personal stories. The drag artists explore soul-deep story sharing techniques as well as the unique talents and skills required from a drag performer.
