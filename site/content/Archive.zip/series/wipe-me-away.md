---
title: Wipe me away (Season 2) (German Premiere)
image: /img/series/wipe-me-away.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/831267978?h=3f87830afa" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Wipe me away (Season 2) (German Premiere)
Country: Canada | Genre: Drama | Creator & Director: Eric Piccoli | Writers: Florence Lafond, Eric Piccoli | Producers: Philippe-A Allard, Marco Frascarelli, Mathieu Paiement, Eric Piccoli | Main Cast: Sarah-Maxine Racicot, Malik Gervais-Aubourg, Charlee-Ann Paul, Jean-Nicolas Verreault, Julie Perreault, Schelby Jean-Baptiste

Two years have passed since Karine, Mélissa and Eddy had to move. If their parents try as best they can to guide them to the adult world, the increasing violence in the neighborhood, however, continues to threaten their future.
