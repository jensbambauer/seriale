---
title: The MUTE Series (World Premiere)
image: /img/series/the-mute-series.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/393643710?h=14580024b3&color=ffffff&title=0&byline=0&portrait=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The MUTE Series (World Premiere)
Country: United Kingdom | Genre: Comedy | Creator: Andy Lambert | Writer & Director: Andy Lambert | Producers: Karen Martinez, Andy Lambert | Main Cast: Kevin Millington, Stewart Alexander, Sinead MacInnes, Bobby Dosanjh, Akie Kotabe, Peter Lofsgard, Clemente Lohr

“The MUTE Series” is a unique, short-form comedy series of deadpan sketches with an absurdist tinge. Each episode is wordless and consists of just one static shot, making the series something of an unusual experiment in narrative comedy minimalism.


