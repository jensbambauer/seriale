---
title: Eva. Connected Through Time (German Premiere) 
image: /img/series/eva-connected-through-time.jpg
---

## Eva. Connected Through Time (German Premiere) 
Country: Russian Federation | Genre: Animation, Fantasy | Creators, Writers & Directors: Anton Outkine, Nata Pokrovskaya | Producers: Anna Mitafidi, Alexandra Potapova, Vadim Belov, Aleksandra Shakhmatova | Main Cast: Evgeny Markov, Elena Khodunova

Eva, an android from the distant future, meets Dima, a young scientist and her original inventor, in the present. Together they will save humanity from a man-made anomaly.
