---
title: Swiss Secrets (International Premiere)
image: /img/series/swiss-secrets.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/v-iB5RxBMzU?si=gzME3CKCKwu5ymXs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Swiss Secrets (International Premiere)
Country: Switzerland | Genre: Thriller, Action, Comedy | Creators: Davide Romeo, Simone Ganser | Writers: Davide Romeo, Simone Ganser, Michele Blum | Director: Davide Romeo | Producers: Simone Ganser, Davide Romeo | Main Cast: Davide Romeo, Simone Ganser, Nina Burri, Miriam Dossena

Secrets collide when two men, burdened by their dark pasts, discover the existence of a hidden criminal underworld operating within the sinister realms of the Dark Web. 

