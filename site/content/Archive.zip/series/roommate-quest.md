---
title: Roommate Quest! (World Premiere)
image: /img/series/roommate-quest.jpg
---

## Roommate Quest! (World Premiere)
Country: Germany | Genre: Comedy | Creator, Director: Florian W. Friedrich | Writer: Julia Römpp | Producers: Tobias Sybel, Marlene Zeitler, Uğur Kurkut (Post Production Coordinator) | Main Cast: Laura Götz, Vincent Lang, Nils Brunkhorst, Matthias Gärtner, Maximilian Held, Eugen Pirvu, Lisa Stiegler, Nadja Zwanziger

Searching for a shared flat room, Laura and David encounter the most eccentric roommates one could imagine. From fortune-tellers and life-changing advice delivered through a cat flap, to a stoned near-death experience. “Roommate Quest!” is a comedic nod to the wild search for a shared flat room.
