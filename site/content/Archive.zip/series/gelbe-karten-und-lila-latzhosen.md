---
title: Gelbe Karten & Lila Latzhosen
image: /img/series/gelbbe-karten-und-lila-latzhosen.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/FRyJQXDV4z0?si=JEG_BbLegycrdQTE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Gelbe Karten & Lila Latzhosen
Country: Germany | Genre: Documentary | Creator, Writer, Director & Producer: Paula Berger | Main Cast: Asya, Annette, Selin, Liselotte, Nathalie, Marlies, Johanna, Ulrike, Chlo, Jutta

What do a doorknob, dungarees and a film projector have in common? They all tell stories from the Borken women's movement. Ten Borken residents from two generations get into conversation and get to the bottom of the history of these objects.
