---
title: Becoming Charlie 
image: /img/series/becoming-charlie.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/894505651?h=6cc1b08fd9" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Becoming Charlie
Country: Germany | Genre: Drama | Creator, Writer: Lion H. Lau | Directors: Kerstin Polte, Greta Benkelmann | Producers: Katrin Haase, Oliver Arnold | Main Cast: Lea Drinda, Katja Bürkle, Sira Anna Faal, Danilo Kamperidis, Antonije Stankovic

“Becoming Charlie” tells the story of Charlie's search for identity. Charlie feels neither like a woman nor like a man. But what is Charlie? The search for and discovery of the own non-binarity catapults not only Charlie but also Charlie's environment out of the comfort zone and shakes up seemingly irrefutable truths. Only in rap does Charlie find a constant and an outlet for own feelings.
