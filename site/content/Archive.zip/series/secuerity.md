---
title: Secürity (World Premiere)
image: /img/series/secuerity.jpg
---
<iframe width="560" height="315" src="https://app.frame.io/presentations/aaea4cf0-8c7f-4526-ad02-4acc288db586" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Secürity (World Premiere)
Country: Germany | Genre: Comedy | Creators, Writers: Ismail Erdogru, Emrah Erdogru | Director: Ismail Erdogru  | Producers: Kristian Wolff, Cristian Ceoroiu, Ismail Erdogru, Emrah Erdogru | Main Cast: Elena Halangk, Jörg Zick, Emrah Erdogru, Ismail Erdogru, Lena Katharina Merle, Thomas Helm, Micky Jukovic, Mylene Dück, Steven C. Langner, Cengiz Erdem

“Secürity” is a comedy series about some underdogs working for Frankfurts cheapest security company. It is a tale about the ups, the downs and about friendship in this never boring business. 

