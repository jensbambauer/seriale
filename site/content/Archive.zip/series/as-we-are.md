---
title: AS WE ARE (World Premiere)
image: /img/series/as-we-are.jpg
---

## AS WE ARE (World Premiere)
Country: Argentina | Genre: Dramedy | Creator: Pedro Levati | Writers, Directors: Pedro Levati, Agustina Levati, Rocío Blanco, Mercedes Scápola, Julieta Otero, Agustina Gatto| Producer: Adrián Garelik | Main Cast: Cande Molfese, Martín Slipak, Victorio D'alessandro, Candela Vetrano, Rafael Ferro, Marina Bellati, Diego Gentile, Héctor Díaz, Magela Zanotta, Sofía Gonzalez Gil, Miguel Ferrería, Carla Pandolfi, María Figueras

6 stories. 6 relationships. 6 directors. “AS WE ARE” talks about the bond with the other, but above all, the bond with oneself.
