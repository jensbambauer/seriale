---
title: K'Road Chronicles (Season 3) (International Premiere)
image: /img/series/k-road-chronicles.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/5A6tpE568ns?si=pYfVRr5WIr4LZjf3" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## K'Road Chronicles (Season 3) (International Premiere)
Country: New Zealand | Genre: Documentary | Creator: Brian Holland | Writer: Paul Oremland | Directors: Paul Oremland, Ella Wells | Producer: Brian Holland | Host: Six

Never before has a series been produced that gives an ongoing voice to the homeless of Aotearoa New Zealand – until the making of “K'Road Chronicles”. The series casts a critical eye on issues often overlooked and brings stories of hope and inspiration from the street community. 
