---
title: The Gliwensbourg Chronicles (World Premiere)
image: /img/series/the-gliwensbourg-chronicles.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/huPPAW1hHS0?si=QWDXkBC_8cBIHPWL" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Gliwensbourg Chronicles (World Premiere)
Country: France | Genre: Dramedy, Western | Creator: Emilie Tommasi | Writer & Director: Emilie Tommasi | Producer: Association ACTIO | Main Cast: Arnaud Thery, Romain Pirosa, Adil Jbilou, Laurent Brebion, Jean-Philippe De Oliveira, Mattieu Bernhard, Nathalie Normand, Myriam Caucheteux, Lahcen Ait Ouali, Jonathan Taverne, Sylvain Csernak, Michel Hettmann, Frédéric Narguet

A French soldier from 1915 travels in time through a tunnel. He arrives in Gliwensbourg in 1925, in the middle of a booty hunt between rival clans. A Berber shaman tells him that he has an obscure mission, but now that he has amnesia, he tries to recover his memory and find out why he is there.

