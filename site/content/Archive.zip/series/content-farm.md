---
title: Content Farm (International Premiere)
image: /img/series/content-farm.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/ygkMGTWfmo4?si=tOsgZiQrXsaRzgTb" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Content Farm (International Premiere)
Country: Canada | Genre: Comedy, Sci-Fi | Creators, Writers & Directors: Lauren Gillis, Alaine Hutton | Producers: Lauren Gillis, Alaine Hutton, Nicholas Ewart | Main Cast: Lauren Gillis, Alaine Hutton

Two rogue bots teach themselves to be human on the internet. Speculative fiction meets cringe comedy, unfolding in the doomscroll.
