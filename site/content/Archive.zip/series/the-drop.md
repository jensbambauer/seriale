---
title: The Drop (European Premiere) 
image: /img/series/the-drop.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/9lrih624xBU?si=H1UyDHPmDb5eBy5w" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## The Drop (European Premiere)
Country: Canada | Genre: Comedy | Creators: Dani Pagliarello, Aisha Evelyna | Writers: Dani Pagliarello, Aisha Evelyna | Directors: Jordan Canning, Dani Pagliarello, Aisha Evelyna | Producers: Elizabeth Yake, Liz Whitmere, Dani Pagliarello, Aisha Evelyna | Main Cast: Dani Pagliarello, Aisha Evelyna, Aurora Browne, Nicole Power, Mark Little

Zara and Polly #werk in Toronto as “professional line-waiters” hired by the rich and lazy to secure exclusive products the day they DROP.
