---
title: The Care-Breakers (European Premiere)
image: /img/series/the-care-breakers.jpg
---

## The Care-Breakers (European Premiere)
Country: Canada | Genre: Dramedy | Creator: Mélodie Bujold-Henri | Writers: Mélodie Bujold-Henri, Annabelle Payant | Director: Zoé Tremblay-Bianco | Producers: Lou Bélanger, Marieme Ndiaye, Rafael Perez | Main Cast: Tiffany Montembault, Jean-Alexandre Létourneau, Melania Maria Balmaceda, Pierre Brassard, Marco Collin, Moshen El Gharbi, Ximena Ferrer, Joelle Jérémie, Dominik Rustam, Roman Viau, Olivia Vo-Van

At 21 years-old, Ysé, who suffers from social anxiety, learns that she must volunteer at the center founded by her late mother to receive her inheritance. Interdependent of her brother, Ysé will have to face her anxieties and her mourning.
