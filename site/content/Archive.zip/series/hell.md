---
title: Hell
image: /img/series/hell.jpg
---
<iframe width="560" height="315" src="https://player.vimeo.com/video/668658865?h=9e05ecd73b" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Hell
Country: Argentina | Genre: Drama | Creators & Producers: Pablo Balmaceda, Santiago Mouriño | Writer & Director: Santiago Mouriño | Main Cast: Agostina Inella, Verónica Gerez, Fabricio Miscione, Alexia Moyano, Juan Barberini, Leonardo Bromberg, Karla Martinez Rios, Argenis Ciriaco, Brenda Peluffo

In a world ruled by algorithms, likes and selfies, Agostina, a young aspiring actress wanders in search of meaning and some kind of human connection when she falls in love with an elusive girl and meets a film director who exposes her to uncomfortable situations.
