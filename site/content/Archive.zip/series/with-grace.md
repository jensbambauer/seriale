---
title: With Grace (Season 3) (German Premiere)
image: /img/series/with-grace.jpg
---

## With Grace (Season 3) (German Premiere)
Country: Australia | Genre: Drama | Creators: Julie Money, Grace Truman | Writers: Grace Truman, Julie Money | Director: Julie Money | Producers: Julie Money, Georgina Connell, Grace Truman | Main Cast: Grace Truman, Ben Wood, Justine Clarke

“With Grace” is a fictionalized version of Grace's life as she negotiates her last days of High School. Her Dad died suddenly when she was 10. When she gets stuck she thinks of what he would do and he is there, sharing his true stories. A bittersweet story about growing up and keeping memories alive.
