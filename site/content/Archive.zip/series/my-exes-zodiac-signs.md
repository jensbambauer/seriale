---
title: My Exes' Zodiac Signs
image: /img/series/my-exes-zodiac-signs.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/pWjrjTzsDSo?si=9b5jMqDvpXNXMYdj" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## My Exes' Zodiac Signs
Country: Brazil | Genre: Comedy, Drama | Creator, Writer: Andrezza Czech | Directors, Producers: Andrezza Czech, Laís Catalano Aranha | Main Cast: Andrezza Czech, Belle Marques, Julianna Gerais, Marília Viana, Rudá, Sol Faganello, Tatiana Ribeiro, Barbara Carrara

Vitoria's love life consists of 12 ex-girlfriends and 12 dumps. To understand why she is “undateable”, she seeks out a therapist who encourages her to follow a journey into her past. Vitoria goes after the reasons for the breakups, meeting each of her exes and trying to discover their zodiac signs.
