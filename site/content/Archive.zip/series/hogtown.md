---
title: Hogtown (Season 2) (International Premiere)
image: /img/series/hogtown.jpg
---

## Hogtown (Season 2) (International Premiere)
Country: Canada | Genre: Drama | Creator, Writer, Director: Josiane Blanc | Producer: Ania Jamila | Main Cast: Cindy Charles, Sandra Dorélas, Jamaal Mansaray, Ted Pluviose, Laurence Barrette, Maika Ferron, Nam Nguyen   

Forced to leave her hometown temporarily, Manu finds it hard to adapt to her new surroundings. She has only one thing on her mind: moving back to Toronto. However, an unexpected encounter turns Manuela's life upside down, calling into question everything she's known and wanted up to now.
