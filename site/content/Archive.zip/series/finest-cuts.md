---
title: Finest Cuts (World Premiere)
image: /img/series/finest-cuts.jpg
---
<iframe width="560" height="315" src="https://www.youtube.com/embed/_cMFhMTNNuU?si=tXj8XnEMwIsA8ffP" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Finest Cuts (World Premiere)
Country: Brazil | Genre: Thriller, Drama, Gore | Creator: Pitaco Filmes | Writers: Isabela Taffuri, Murilo Bonini | Director: Murilo Bonini | Producer: Isabela Taffuri | Main Cast: Guilherme Corrêa, Luiz Rodriguez, Eduardo Ramella, Giovana Telles, Brenda Diniz, Raul Rozados, Hélcio Henriques

After being unfairly fired, the introverted chef Alfredo accidentally gets involved in an exclusive gathering of chefs, where he discovers a dark world of culinary. As disturbing secrets are revealed, he gets involved in a dangerous web of betrayal and fights for his survival.
