---
title: Sasha Counters! (International Premiere)
image: /img/series/sasha-counters.jpg
---

## Sasha Counters! (International Premiere)
Country: Russian Federation | Genre: Dramedy | Creator: Anna Zaytseva | Writers: Anna Zaytseva, Daria Maslovskaya | Director: Anna Zaytseva | Producers: Alexander Malinkovich, Anna Zaytseva, Makar Kozhuhov, Marina Kataya | Main Cast: Anna Potebnya, Alikhan Nurzhauov, Azamat Nigmanov, Nastasya Kerbengen, Polina Denisova, Kirill Rusin, Evgenii Kuncevich, Denis Nikitin 

The two teenagers Sasha, boxer from Moscow, and Kazakh rapper Mamazhan involuntarily become stepsister and stepbrother. They do everything to get rid of each other, but their efforts cause the opposite effect.
