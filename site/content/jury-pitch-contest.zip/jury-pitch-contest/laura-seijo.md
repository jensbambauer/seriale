---
title: Laura Seijo
image: /img/jury-pitch/laura-seijo.jpg
shortdescription: Producer & Distributor | UN3 | Argentina
---
<img src="/img/jury-pitch/laura-seijo.jpg">
## Laura Seijo

UN3 Producer and Distributor | TV-Channel University Buenos Aires | Argentina

Laura Seijo is a writer and producer. Since 2017 she has been working at UN3, an Argentine channel dedicated exclusively to short series. She currently works in content programming, production and distribution. She is also a writer of screenplays, narrative and poetry, and is trained in performing arts, working as an actress and assistant director in several plays in Buenos Aires.
