---
title: Adrian Garelik
image: /img/jury-pitch/adrian-garelik.jpg
shortdescription: CEO | Flixxo | Argentina
---
<img src="/img/jury-pitch/adrian-garelik.jpg">
## Adrian Garelik

CEO | Flixxo | Argentina

Adrian Garelik is a filmmaker and entrepreneur from Argentina. In 2016, after a succesful crowdfunding campaign, he funded Flixxo, the platform for microseries that rewards both its users and creators with cryptocurrencies. Flixxo was launched in 2020, gathering more than 70,000 users in Latin America in the first months. Now Flixxo is ready to take over the world :) In addition, he was the scriptwriter of some movies and series, including To fool a thief (Disney, 2013), Entrapped (Netflix, 2015) and In the sights (HBO+, 2021) He has also produced the movie The Red Star (2021) and the microseries Alejo and Valentina, Neptunia, ALT ESC, Movies in real life, Backstage, Bizarre Creatures and Death on Arrival.


