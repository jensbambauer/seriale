---
title: Riccardo Cannella
image: /img/speaker/riccardo-cannella.jpg
shortdescription: Cinnamon Production | Sicily Web Fest
---
<img src="/img/speaker/riccardo-cannella.jpg">
## Riccardo Cannella

Cinnamon Production | Sicily Web Fest

Award-winning director, producer and screenwriter. Founder of “Cinnamon Digital Cinema Production“ and “Sicily Web Fest“. First to sell a web series to pay-TV. Considered one of the spokespersons for digital serialization, in Italy and abroad. His productions have won over 40 awards worldwide.