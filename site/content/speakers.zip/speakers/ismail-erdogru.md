---
title: Ismail Erdogru
image: /img/speaker/ismail-erdogru.jpg
shortdescription: Director, Writer
---
<img src="/img/speaker/ismail-erdogru.jpg">
## Ismail Erdogru

Director, Writer

Ismail Erdogru studied Film at the Hda (Hochschule Darmstadt). The pilot “Security“ is his Bachelor project, currently he is writing the whole season. 