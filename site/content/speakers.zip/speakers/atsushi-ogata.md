---
title: Atsushi Ogata
image: /img/speaker/atsushi-ogata.jpg
shortdescription: Creator, Producer | Globetrot Production
---
<img src="/img/speaker/atsushi-ogata.jpg">
## Atsushi Ogata

Creator, Producer | Globetrot Production

Atsushi Ogata born in Japan, raised partly in the U.S. He is a Graduate of M.I.T. and Harvard. In Germany and Holland he received funds for screenwriting. He appeared weekly as a comedian on Dutch TV. He  wrote and directed “Cast Me If You Can” (feature -- screened in theaters, airlines and on TV). He created the web series “Trick or Treat: I LOVE America!”, “Yukata Cowboy” , “Mona Lisa Cowboy.”

