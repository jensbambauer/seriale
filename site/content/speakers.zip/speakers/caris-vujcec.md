---
title: Caris Vujcec
image: /img/speaker/caris-vujcec.jpg
shortdescription: Creator, Director, Actress
---
<img src="/img/speaker/caris-vujcec.jpg">
## Caris Vujcec

Creator, Director, Actress

Caris Vujcec is a New York City-based actress, creator, producer, director and filmmaker best known for her role in the NBC-network television series, Law and Order: Criminal Intent and SVU. Caris created, wrote, produced, co-directed and leads the cast of the international award-winning series “The Pepper Project“, that won over 25 awards and nominations and in 2017 got entitled Number 1 U.S.-digital series in the “Web Series World Cup“. A passionate-supporter of indie-creator content, Caris has presented and served on panels at such U.S.-based and international festivals (with The Pepper Project) at “die Seriale“, “Sicily Web Fest“ and “Austin Web Fest“ to name a few. She has been pitching her new thriller-horror series in development, “CENOTE“ at festivals and in competitions. Caris looks forward to continuing the story of Pepper in 2019 as well as other original narratives highlighting multi-faceted strong female characters and complex casts, collaborating with the many talented colleagues she has met. 
