---
title: Kristian Wolff
image: /img/speaker/kristian-wolff.jpg
shortdescription: Screen & Development Writer
---
<img src="/img/speaker/kristian-wolff.jpg">
## Kristian Wolff 

Screen & Development Writer

Kristian Wolff is screenwriter, head writer and development writer since 2004. He studied film in Norway, Denmark and the UK and then began working at Constantin-Entertainment in Munich. Since 2008 he writes as freelancer for German public and private television. Among other works, he developed the children's series “Fluch des Falken“ (BR) and the web series “Antarktika“ (funk). Currently he writes for the comedy-crime series “Hubert ohne Staller“ (BR) and is developing of a pilot (RTL2).