---
title: Anna-Marlene Wirtz
image: /img/speaker/anna-marlene-wirtz.jpg
shortdescription: Actress, Creator
---
<img src="/img/speaker/anna-marlene-wirtz.jpg">
## Anna-Marlene Wirtz 

Actress, Creator

Anna-Marlene Wirtz, of Welsh & German origin, is an actress working predominantly in Film, Theatre and Voice over’s. In 2005 Anna spent time with the National Youth Theatre of Wales before starting her BA (Hons) in Acting at Italia Conti Academy of Theatre Arts, London. While training Anna was rewarded with the prestigious Lilian Baylis Award, presented to her by Dame Judi Dench at the Old Vic Theatre. After completing Drama school in London, she landed great roles in several theatre productions, including “Salome“ at the Roundhouse, “Julius Caesar“ at the Blue Elephant Theatre,  Shaw’s “Misalliance“ as Lina Szczepanowska at the Tabard Theatre, as well as‚“The Underpants“ as Louise Maske at Das Internationale Theater, Frankfurt. Anna has a love for film and storytelling, so she got together with actress Elena Halangk and created the comedy episodes of two friends and their day to day dilemmas called  Emmy & Christin. Currently, Anna is working on the Hesse produced digital series “Anomalie“, 2018  (Tag & Nacht Media, Darmstadt), playing the role of Luisa Ahrens.