---
title: Laura Seijo
image: /img/speaker/seijo-laura.jpg
shortdescription: Writer, Producer | UN3
---
<img src="/img/speaker/seijo-laura.jpg">
## Laura Seijo

Writer, Producer | UN3

She graduated as a screenwriter in E.N.E.R.C. She works since 2013 as a producer, scriptwriter and coordinator in several audiovisual projects. She is currently a producer and responsible for distribution at UN3. She wrote the short film "Desvío", official selection at the Mar del Plata International Film Festival in 2013, the documentary "The days without time" and the webseries T.R.E.N., both projects in development stage. She is also trained in performing arts and working as an actress and assistant director in several plays in Buenos Aires.
