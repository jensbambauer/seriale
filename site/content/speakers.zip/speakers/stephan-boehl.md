---
title: Stephan Böhl
image: /img/speaker/stephan-boehl.jpg
shortdescription: Writer, Producer | Tag & Nacht Media
---
<img src="/img/speaker/stephan-boehl.jpg">
## Stephan Böhl

Writer, Producer | Tag & Nacht Media

Stephan Böhl studied Digital Media, with focus on sound at Hochschule Darmstadt. In master course Media Direction, he focused also on conception and film production. In 2013 he realized the internationally awarded web series “Mem“ together with his colleagues Christian and Thomas. Together they founded the Media Production Company “Tag & Nacht Media“. Stephan is working as an Author and in the fields of Conception, Film & Music Production and Sound Design.

