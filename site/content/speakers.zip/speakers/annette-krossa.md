---
title: Annette Krossa
image: /img/speaker/annette-krossa.jpg
shortdescription: Actress, Writer, Producer
---
<img src="/img/speaker/annette-krossa.jpg">
## Annette Krossa 

Actress, Writer, Producer

Annette Krossa completed her musical training in 2002 at Stage School Hamburg, then she studied in London to become a Certified Master Teacher at Estill Modal. She participated in numerous musicals (“Cabaret“, “Chicago“) and theater productions. Annette also teaches singing at various music schools. In 2018 she wrote the series “The Green Challenge“, in which she also plays the lead role. The series was awarded with the “Grüner Drehpass“, Film Funding Hamburg and the “Green Award“, Apulia Webfest.
