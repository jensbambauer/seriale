---
title: Young Man Kang
image: /img/speaker/young-man-kang.jpg
shortdescription: YMK Films | Seoul Webfest
---
<img src="/img/speaker/young-man-kang.jpg">
## Young Man Kang

YMK Films | Seoul Webfest

Young Man Kang directed several feature films and web series. All feature films have been released on VOD in Netflix and Amazon and DVD in the US, and have sold in 15 countries. He has a total of 11 awards from a number of film festivals and webfests. Young Man Kang collaborated with fellow film "Avatar" alumni, Just Cause 3D, on his "4D Experience" Project. He is a founder and executive director of the “Seoul Webfest“ & “Asia Web Awards“. He has been a jury member at several webfests such as Die Seriale, Roma Webfest and many more.
