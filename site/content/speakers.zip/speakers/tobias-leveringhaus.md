---
title: Tobias Leveringhaus
image: /img/speaker/Leveringhaus_Gross.jpg
shortdescription: Sodawasser Pictures | Kinoflimmern
---
<img src="/img/speaker/Leveringhaus_Gross.jpg">
## Tobias Leveringhaus

Sodawasser Pictures | Kinoflimmern

Since he studied film at “ifs“ Cologne, he is interested in scenarios of classical and future media usage. With “Sodawasser Pictures“ (SWP) he created the possibility, to accompany movies from the development over financing and realization until distribution. An important part is his video-on-demand platform “Kinoflimmern“, which has by now more than 700 titles. As program director of the cinema “Turistarama“ in Cologne, he can also guarantee the classical distribution way via cinema. Through his network, he speaks with movie distributors and cinemas, to bring movies on the big screen. In 2018 he was awarded with the cinema programming prize, by “Film- und Medienstiftung NRW“, for outstanding cinema program in a Cologne cinema.

