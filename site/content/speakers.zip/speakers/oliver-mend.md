---
title: Oliver Mend
image: /img/speaker/oliver-mend.jpg
shortdescription: A Film To Kill For | Seriesland
---
<img src="/img/speaker/oliver-mend.jpg">
## Oliver Mend

A Film To Kill For | Seriesland

Director, actor, editor and really prolific in everything he attemps, Oliver has directed over 30 works as a writer and director. After studying Fine Arts, he studied a Master in Audiovisual Company Management and excelled in directing genre films, digital series, short films and music videos, in his previous company “Happy Latex Productions“, and also now at “A Film To Kill For“.