---
title: Dennis Albrecht
image: /img/speaker/dennis-albrecht.jpg
shortdescription: Creator, Producer | Unsere Serien
---
<img src="/img/speaker/dennis-albrecht.jpg">
## Dennis Albrecht

Creator, Producer|Unsere Serien

Founder of “Unsere Serien“. Director and producer of the web series “Filmcity“ and “We all Love Football“ and co-founder of “die Seriale“.