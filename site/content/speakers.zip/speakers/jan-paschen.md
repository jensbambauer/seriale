---
title: Jan Paschen
image: /img/speaker/jan-paschen.jpg
shortdescription: Director, Writer, Producer
---
<img src="/img/speaker/jan-paschen.jpg">
## Jan Paschen

Director, Writer, Producer

Born in Hadamar, grown up in Westerwald, living in the Rhine-Main area. He always had a keen interest in the creative industry. He studied communication design at RheinMain University of Applied Sciences and spent a semester abroad in Jordan in 2016/17. In 2018 he achieved the Bachelor of Arts with focus on documentary film. Active as a freelance filmmaker and graphic designer. 