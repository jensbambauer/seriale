---
title: Shamila Lengsfeld
image: /img/speaker/shamila-lengsfeld.jpg
shortdescription: Director
---
<img src="/img/speaker/shamila-lengsfeld.jpg">
## Shamila Lengsfeld

Director

Shamila Lengsfeld is a film maker based in Cologne, Germany. Since she graduated at Middlesex University with a Bachelor of Filmmaking in 2016, she works as a freelance film maker. Her film projects were shown internationally at film festivals and exhibitions. Her short film “Blake” (2017) has won the “German Newcomer Film Award”.