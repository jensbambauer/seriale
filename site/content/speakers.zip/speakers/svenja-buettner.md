---
title: Svenja Büttner
image: /img/speaker/svenja-buettner.jpg
shortdescription: Executive Producer | Eumel Film
---
<img src="/img/speaker/svenja-buettner.jpg">
## Svenja Büttner

Executive Producer | Eumel Film

Svenja Büttner studied time-based media with a focus on film production at the University of Mainz. Her many years of professional experience as AD and production manager for advertising, image films and scenic short films make her one competent leader in all phases of a film production. Svenja also accumulates a lot of experience through her work as a Producer at the Mainz film production company “Kontrastfilm“. Her references include advertising campaigns for Deutsche Bahn and Lidl, training films for Porsche AG, and short films such as “Laser Pope“ (2016), “Mia and the Owl“ (2017) and “Little Achilles“ (2019) 
In 2017 Jansen and Büttner established “Eumel Film“ to pursue their shared objective to make feature films for and with children starting with “Little Achilles“.
