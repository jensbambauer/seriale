---
title: Sergio Sosa
image: /img/speaker/sergio-sosa.jpg
shortdescription: VP of Operations | Flixxo
---
<img src="/img/speaker/sergio-sosa.jpg">
## Sergio Sosa

VP of Operations | Flixxo

Sergio Sosa is an Argentinian audiovisual artist, music producer and Blockchain enthusiast. With a filmmaking degree from the University of Buenos Aires and studies at the Conservatory of Music Astor Piazzolla and different computer programming schools, he feels at home working in the middle of art and technology. Currently he is the VP of Operations of Flixxo, an innovative blockchain based video platform, where he focuses on content and production.

