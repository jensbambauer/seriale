---
title: Matthias Noe
image: /img/speaker/matthias-noe.jpg
shortdescription: Director, Writer | Spessart Tales
---
<img src="/img/speaker/matthias-noe.jpg">
## Matthias Noe

Director, Writer | Spessart Tales

Born and raised near Hanau, the birthplace of the Brothers Grimm, Matthias instantly fell under the spell of legends and tales of the supernatural. While studying in Mainz, he proofread screenplays for ZDF, Germany’s largest broadcaster of fictional programs, and sought every opportunity to work on film sets. After graduating he worked as continuity, assistant director, and in post production and visual effects for several nationwide fictional programs and commercials, whilst never forgetting about his own stories. Eventually, in 2016, he teamed up with a dedicated crew of film professionals from the Frankfurt area and launched the web series project “Spessart Tales”. 