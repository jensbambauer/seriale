---
title: Ariana Saiegh
image: /img/speaker/ariana-saiegh.jpg
shortdescription: Director, Producer | UN3
---
<img src="/img/speaker/ariana-saiegh.jpg">
## Ariana Saiegh 

Director, Producer | UN3

She is a producer and director and graduated from „Universidad del Cine“ (FUC) in 2007. She has extensive experience in production of TV programs, documentaries, films and short-form series. She is also working in the direction and production coordination of several projects and works at UN3 since 2015 as a producer, and as Production Coordinator since 2017.