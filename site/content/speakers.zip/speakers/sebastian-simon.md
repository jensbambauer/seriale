---
title: Sebastian Simon
image: /img/speaker/sebastian-simon.jpg
shortdescription: Managing Director, Producer | PixelPEC
---
<img src="/img/speaker/sebastian-simon.jpg">
## Sebastian Simon

Managing Director, Producer | PixelPEC

Sebastian graduated his film study at University of Art and Design Offenbach in 2009.
After 4 years working as project manager and assistant of managing director at Hessen Film and Media Academy, Sebastian founded PixelPEC in 2014. He now is the producer and CEO of PixelPEC. The company is specialized in animation and postproduction, and in addition to its own web series, TV formats and animations for TV, culture and business are created here.

