---
title: George Reese
image: /img/speaker/george-reese.jpg
shortdescription: SEEKA TV
---
<img src="/img/speaker/george-reese.jpg">
## George Reese

SEEKA TV

George Reese is an entrepreneur, author, and filmmaker. A graduate in Philosophy from “Bates College“, his early career began in television before taking a detour in technology. As a technologist, he wrote several books and became an entrepreneur. After leaving “Dell“, Mr. Reese returned to television and film as a writer, producer, and director.