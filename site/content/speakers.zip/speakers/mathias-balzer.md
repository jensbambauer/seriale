---
title: Mathias Balzer
image: /img/speaker/mathias-balzer.jpg
shortdescription: Writer, Cultural Journalist | Edition Frida
---
<img src="/img/speaker/mathias-balzer.jpg">
## Mathias Balzer

Writer, Cultural Journalist | Edition Frida

Mathias Balzer is working as cultural journalist at the "bzBasel" since 2017 and writes for "AZ" and "Schweiz am Wochenende". From 2012 to 2016, he was head of the culture redaction of "Südostschweiz" in Chur. Previously he worked in various functions at the theater and for events, including the work as dramaturg with Markus Luchsinger at the theater Chur. He wrote “Hanshi Charlie - Kampf und Lebenskunst“ (German and English), published by Edition Frida.