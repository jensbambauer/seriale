---
title: Maria Eva De Sanctis
image: /img/speaker/maria-eva-de-sanctis.jpg
shortdescription: Writer, Director
---
<img src="/img/speaker/maria-eva-de-sanctis.jpg">
## Maria Eva De Sanctis

Writer, Director

Student, soon to graduate from the Fernando Birri Film and Audiovisual Arts Institute. Screenwriter and director of short films and web series. She is part of the executive production of the web series “Prohibido Silbar“/“It’s forbidden to whistle“. Wrote the script and made the address. She is currently working on her new web series called “Pantanos“. Lives in Santa Fe, Argentina. She is a creative person, with her own initiative and eager to progress and live in the audiovisual industry. As a recreation, draw and paint.
