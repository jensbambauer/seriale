---
title: Rose of Dolls
image: /img/speaker/rose-of-dolls.jpg
shortdescription: A Film To Kill For | Seriesland
---
<img src="/img/speaker/rose-of-dolls.jpg">
## Rose of Dolls

A Film To Kill For | Seriesland

Pioneer & creative actress, producer, director and writer, Rose is Suma Cum Laude Phd. in Social Communication with her thesis "Webseries, the audiovisual revolution", she is also active in film production in her company “A Film To Kill For“, and is always struggling to help new generations of filmmakers and promote women in film. 