---
title: Liudmila Filonenko
image: /img/speaker/liudmila-filonenko.jpg
shortdescription: The Digital Reporter | Realist Web Fest
---
<img src="/img/speaker/liudmila-filonenko.jpg">
## Liudmila Filonenko

The Digital Reporter | Realist Web Fest

Liudmila Filonenko is Director of Communications at the Russian web series festival “Realist Web Fest“. She is also a correspondent of Russia's first media about the web series industry “The Digital Reporter“. This project was founded in 2017 and has become a media platform that not only informs about web industry, but also brings together creators of web series, organizes pitchings and professional meetings. In 2018 “The Digital Reporter“ team held the first Russian web series festival “Realist Web Fest“ and created international web awards. In the meantime the “The Digital Reporter“ is producing its own web series.
