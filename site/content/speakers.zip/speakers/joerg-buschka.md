---
title: Jörg Buschka
image: /img/speaker/joerg-buschka.jpg
shortdescription: Director, Producer, Reporter
---
<img src="/img/speaker/joerg-buschka.jpg">
## Jörg Buschka

Director, Producer, Reporter
 