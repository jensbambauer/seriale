---
title: Catherine Lieser
image: /img/speaker/catherine-lieser.jpg
shortdescription: HessenFilm and Media
---
<img src="/img/speaker/catherine-lieser.jpg">
## Catherine Lieser

HessenFilm and Media

