---
title: Anja Horstmann
image: /img/speaker/anja-horstmann.jpg
shortdescription: Historian | JLU Giessen
---
<img src="/img/speaker/anja-horstmann.jpg">
## Anja Horstmann 

Historian | JLU Giessen

Anja Horstmann, historian, specialization: media history, film and photo history. Since 2014 research associate at the Institute of Specialist Journalism History, University of Giessen. Studied history and German at the University of Bielefeld. Research and promotion on filming from the Warsaw Ghetto.

