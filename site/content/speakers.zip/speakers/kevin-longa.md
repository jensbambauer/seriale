---
title: Kevin Longa
image: /img/speaker/kevin-longa.jpg
shortdescription: Director, Writer
---
<img src="/img/speaker/kevin-longa.jpg">
## Kevin Longa 

Director, Writer

Kevin Longa is an internationally award-winning filmmaker. He explores world cultures through the perspective of food and the lens of the camera. He's done this ever since he produced his first documentary investigating food corporations in high school. Currently he's producing "TASTE" — an internationally award-winning documentary series that uncovers true stories of food entrepreneurs around the world. 