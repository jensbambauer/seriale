---
title: Thomas Schneider-Trumpp
image: /img/speaker/thomas-schneider-trumpp.jpg
shortdescription: CEO | Snepic | Watch Movies 
---
<img src="/img/speaker/thomas-schneider-trumpp.jpg">
## Thomas Schneider-Trumpp

CEO | Snepic | Watch Movies

Thomas Schneider-Trumpp is a successful, creative thinking, results-oriented executive with over 25 years of international experience in film production. As a creative mind, producer, business developer and business manager, he worked for TV and web series. His background ranges from experiences as entrepreneur in the field of web-only productions to business development with pragmatic approaches to feasibility and business concepts with a focus on creation.

