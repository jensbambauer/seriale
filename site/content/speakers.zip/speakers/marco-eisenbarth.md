---
title: Marco Eisenbarth
image: /img/speaker/marco-eisenbarth.jpg
shortdescription: Director, Cinematographer
---
<img src="/img/speaker/marco-eisenbarth.jpg">
## Marco Eisenbarth 

Director, Cinematographer