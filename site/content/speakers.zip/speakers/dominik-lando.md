---
title: Dominik Lando
image: /img/speaker/dominik-lando.jpg
shortdescription: Producer | Spessart Tales
---
<img src="/img/speaker/dominik-lando.jpg">
## Dominik Lando

Producer | Spessart Tales

From lighthouses to will-o'-wisps: With roots on the shores of the Baltic Sea, Dominik studied business management in Frankfurt, to later work in the marketing departments of Mindfactory AG in Wilhelmshaven and Ströer SE & Co. in Frankfurt. Bitten by the film bug though, he had also worked as a PA on cinema and TV productions during his studies and eventually turned his skill set in customer acquisition and finance towards the film business. Today he works as an independent adviser for film production companies and as producer for the mystery fantasy series “Spessart Tales“. Dominik has co-produced three episodes together with writer and director Matthias Noe, the fourth episode is in pre-production.

