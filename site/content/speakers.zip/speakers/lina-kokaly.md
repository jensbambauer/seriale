---
title: Lina Kokaly
image: /img/speaker/lina-kokaly.jpg
shortdescription: Editor | funk | Radio Bremen | ARD
---
<img src="/img/speaker/lina-kokaly.jpg">
## Lina Kokaly

Editor | funk | Radio Bremen | ARD

Lina Kokaly studied literature and started as a trainee at Radio Bremen which included working at ARD in Berlin and at the dpa office in Istanbul. She originated the web series "Wishlist" and “Klicknapped” as script editor. Since 2014 she works as a moderator and reporter for “Radio Bremen“ and is mostly responsible for serial formats of "funk" and audio drama series for the ARD Audiothek.
