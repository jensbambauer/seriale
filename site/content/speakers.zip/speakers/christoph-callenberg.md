---
title: Christoph Callenberg
image: /img/speaker/christoph-callenberg.jpg
shortdescription: Writer
---
<img src="/img/speaker/christoph-callenberg.jpg">
## Christoph Callenberg 

Writer

Christoph Callenberg studied law in Bonn and Berlin and script writing at dffb in Berlin. Since 2005 he works as independent author and since 2012 he is teaching at the Skript Akademie, Dekra college of media. He wrote numerous scripts for German television series. 
