---
title: Ludmila Wagnest
image: /img/speaker/ludmila-wagnest.jpg
shortdescription: Director, Producer, Writer
---
<img src="/img/speaker/ludmila-wagnest.jpg">
## Ludmila Wagnest

Director, Producer, Writer

Ludmila Wagnest was born in Santa Fe, she is a Graduate in filmmaking at Institute Superior of Cinema and Audiovisual Arts in Argentina, Santa Fe City. She is director, producer, screenwriter and editor. She has been working for her institute on different projects and different video-clips like “Gogo Clap”, “Delfino Flow” and “Alguien mató algo”. In addition she made the coverage of the bicycle event “Alley-Cat” of Santa Fe city in the years 2016, 2017 and 2018.


