---
title: Genie
image: /img/speaker/genie.jpg
shortdescription: Actress
---
<img src="/img/speaker/genie.jpg">
## Genie

Actress
