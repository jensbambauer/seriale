---
title: Luis Balzer
image: /img/speaker/luis-balzer.jpg
shortdescription: Creator, Director
---
<img src="/img/speaker/luis-balzer.jpg">
## Luis Balzer 

Creator, Director

Luis Balthisar Balzer, son of Mathias Balzer, graduated in 2018 with Bachelor of the course Cast - new media at ZHdK in Zurich. His three-part web series “Hanshi Charlie“ was included in the ZHdK highlights and selected at various film festivals. He currently works as a video storyteller and DJ in Zurich.
