---
title: Sergio Sosa
image: /img/jury-pitch/sergio-sosa.jpg
shortdescription: Flixxo | Argentina
---
<img src="/img/jury-pitch/sergio-sosa.jpg">
## Sergio Sosa

VP of content | Flixxo | Argentina

Sergio Sosa is an Argentinian producer, distributor and the VP of Content of Flixxo, an innovative blockchain-based video platform and production studio focused on short form series. He has been part of Flixxo since 2018, where he coordinates the production of original series, the onboarding of third party shows into the platform, and all content-related operations. 
