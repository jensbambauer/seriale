---
title: Frank Böhm
image: /img/jury-pitch/frank-boehm.jpg
shortdescription: Hessischer Rundfunk | Germany
---
<img src="/img/jury-pitch/frank-boehm.jpg">
## Frank Böhm

Program Director, Format Developer, Journalist | Hessischer Rundfunk | Germany

Frank Böhm studied politics, media sociology and education with a master's degree. He learned the TV business at RTL. After five years, he switched to Hessischer Rundfunk, started as a reporter and editor at Hessenschau, and a short time later invented and built up the regional tabloid format “maintower” and also headed it up. After more than ten years, he moved on to the Hessenschau. Here, too, as editorial director. Since 2018, he has been in charge of the staff unit New Formats Moving Image and develops formats for the Mediathek.


