---
title: Julia Weber
image: /img/jury-pitch/julia-weber.jpg
shortdescription: Global Screen - A brand of Telepool | Germany
---
<img src="/img/jury-pitch/julia-weber.jpg">
## Julia Weber

Head of International Sales & Acquisitions | Global Screen - A brand of Telepool | Germany

Julia Weber, Head of International Sales and Acquisitions at Global Screen, the international distribution arm of Telepool based in Munich, has worked in the media business for more than 25 years. She joined Telepool in 2008 and is currently responsible for all aspects of feature film and series at Global Screen, from co-development to co-productions, acquisitions to presales.
