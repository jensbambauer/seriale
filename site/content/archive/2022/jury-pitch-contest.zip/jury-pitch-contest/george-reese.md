---
title: George Reese
image: /img/jury-pitch/george-reese.jpg
shortdescription: Seeka TV | United States 
---
<img src="/img/jury-pitch/george-reese.jpg">
## George Reese

CEO of Seeka TV | United States 

George Reese has worked in television, film, and technology as an entrepreneur and independent filmmaker for over 30 years. He has started several companies and worked on dozens of productions in just about every behind-the-camera role imaginable. His previous company, Enstratius, was acquired by Dell in 2013.