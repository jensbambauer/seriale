---
title: Melvina Kotios
image: /img/jury-pitch/melvina-kotios.jpg
shortdescription: Das kleine Fernsehspiel ZDF | Germany
---
<img src="/img/jury-pitch/melvina-kotios.jpg">
## Melvina Kotios

Commissioning Editor | Das kleine Fernsehspiel ZDF | Germany

Melvina Kotios is working as commissioning editor at ZDF Das kleine Fernsehspiel and HR Digital Media. She is in charge of feature films (fictional and documentaries) and always looking for innovative online formats. After finishing her master’s degree in literature and media she worked as a video journalist, editor and online content producer in Munich and Hamburg.
