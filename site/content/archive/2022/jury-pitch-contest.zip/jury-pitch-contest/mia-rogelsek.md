---
title: Mia Rogelsek
image: /img/jury-pitch/mia-rogelsek.jpg
shortdescription: Content and Production Expert | Germany
---
<img src="/img/jury-pitch/mia-rogelsek.jpg">
## Mia Rogelsek

Content and Production Expert | Digital Content Production Lead | Germany

Mia Rogelsek switched industries from Music&Talent to Design&Creative and has found her home in Content&Production, where she is combining all these creative disciplines and focusing on digital platforms for an international and global audience. She worked for ViacomCBS (Comedy Central, MTV, Paramount, Nickelodeon) on digital content for Europe, Asia, Africa and Middle East.
